
import React from 'react';
import { NavItem, StatItem } from './types';

export const NAV_ITEMS: NavItem[] = [
  { label: 'Work', href: '#work' },
  { label: 'About', href: '#about' },
  { label: 'Resume', href: '#resume' },
  { label: 'Contact', href: '#contact' },
];

export const TECH_STACK = [
  'Node.js',
  'TypeScript',
  'PostgreSQL',
  'Docker',
  'AWS',
  'Solidity',
];

export const STATS: StatItem[] = [
  { value: '3+', label: 'Years Exp.' },
  { value: '20+', label: 'Projects' },
  { value: '100%', label: 'Reliability' },
];

export const AVATAR_URL = 'https://lh3.googleusercontent.com/aida-public/AB6AXuDJG4IFEWvvmB-KoqEr79iai5Z0Ud-_oNLEDruAtCSwEmRirVl-CrCMwhA76MaWKJfDW-Ew8yv09598GgG7FpJgNekHMIdbTiEmKPcl2sznaOpF3ReeeqSoKnYaBdzBj1uoyIGUrtIZAGIU6jLByRcRCVvM0YAsc7tTrznQWq2c4z5o9m0XaamswwOBlXTkZrsrHxE_vFFVEiwwNdfpE__KqUgFAfuhz2_LnnMNkQbEVSSsBUbv_OUCOIIHAf2eSFRVKgW-L7aAPb0';
