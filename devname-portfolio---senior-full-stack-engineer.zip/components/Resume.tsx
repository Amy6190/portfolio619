
import React from 'react';

export const Resume: React.FC = () => {
  return (
    <section id="resume" className="relative py-24 md:py-32 bg-[#0f172a] overflow-hidden">
      {/* Ambient Background Glows */}
      <div className="absolute top-[20%] right-[10%] w-[500px] h-[500px] bg-primary/5 rounded-full blur-[120px] pointer-events-none"></div>
      <div className="absolute bottom-[10%] left-[5%] w-[400px] h-[400px] bg-purple-500/5 rounded-full blur-[100px] pointer-events-none"></div>

      <div className="container mx-auto px-6 max-w-5xl relative z-10">
        {/* Header Section */}
        <div className="flex flex-col gap-8 md:flex-row md:items-start md:justify-between mb-16">
          <div className="flex-1">
            <div className="inline-flex items-center gap-2 rounded-full bg-primary/10 px-4 py-1.5 text-[10px] font-bold text-primary mb-6 border border-primary/20 uppercase tracking-[0.2em]">
              <span className="relative flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-primary opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-primary"></span>
              </span>
              Open to Opportunities
            </div>
            <h2 className="text-4xl md:text-6xl font-black tracking-tight text-white mb-6 leading-tight">
              Reliable Systems.<br/>
              <span className="text-slate-500">Scalable Architecture.</span>
            </h2>
            <p className="text-slate-400 text-lg max-w-2xl leading-relaxed font-light">
              Senior Full Stack & Backend Engineer specialized in Node.js, Web3 protocols, and Generative AI integration. I build robust digital infrastructure that scales effortlessly.
            </p>
          </div>

          {/* Floating Download Card */}
          <div className="glass-card p-8 rounded-3xl flex flex-col gap-5 min-w-[300px] shadow-2xl border border-white/5 hover:-translate-y-2 transition-transform duration-500">
            <div className="flex items-start justify-between">
              <div>
                <p className="text-[10px] text-slate-500 font-bold uppercase tracking-widest mb-1">Latest Version</p>
                <p className="text-white font-bold">Resume_v4.2.pdf</p>
              </div>
              <span className="material-symbols-outlined text-slate-500">description</span>
            </div>
            <div className="h-px w-full bg-white/5"></div>
            <button className="flex w-full cursor-pointer items-center justify-center gap-3 rounded-xl h-14 bg-primary hover:bg-primary-dark text-background-dark font-black transition-all shadow-xl hover:shadow-primary/40 group">
              <span className="material-symbols-outlined font-bold group-hover:animate-bounce">download</span>
              <span className="uppercase tracking-wider text-sm">Download PDF</span>
            </button>
            <p className="text-[10px] text-center text-slate-500 font-mono">Updated: Oct 2023 • 2.4 MB</p>
          </div>
        </div>

        {/* ATS Friendly Summary */}
        <div className="glass-card rounded-3xl p-8 md:p-10 border-l-4 border-l-primary mb-20 border border-white/5">
          <h3 className="text-white text-xl font-bold mb-5 flex items-center gap-3">
            <span className="material-symbols-outlined text-primary">manage_search</span>
            Professional Summary
          </h3>
          <p className="text-slate-300 leading-relaxed font-light text-lg">
            Results-oriented Senior Backend Engineer with 5+ years of experience in designing and deploying microservices architectures. Proven track record in optimizing API latency by 40% and reducing infrastructure costs through containerization (Docker/Kubernetes). Expert in Node.js ecosystems and recently focused on integrating LLMs for enterprise GenAI solutions. Dedicated to writing clean, maintainable code and mentoring junior developers in CI/CD best practices.
          </p>
        </div>

        {/* Experience Timeline Section */}
        <div className="mb-20">
          <div className="flex items-center justify-between mb-12 border-b border-slate-800 pb-6">
            <h3 className="text-white text-3xl font-black tracking-tight uppercase">Professional Experience</h3>
            <span className="text-slate-500 font-mono text-sm">2019 - Present</span>
          </div>

          <div className="relative pl-4 md:pl-0">
            {/* Vertical Line */}
            <div className="absolute left-[30px] md:left-[40px] top-4 bottom-0 w-px bg-slate-800"></div>

            {/* Experience Items */}
            <div className="space-y-16">
              {/* Job 1 */}
              <div className="relative grid grid-cols-[60px_1fr] md:grid-cols-[80px_1fr] gap-x-8 group">
                <div className="flex flex-col items-center pt-2 z-10">
                  <div className="h-14 w-14 rounded-2xl bg-slate-800/80 border-2 border-primary flex items-center justify-center shadow-[0_0_20px_rgba(43,173,238,0.3)]">
                    <span className="material-symbols-outlined text-primary text-2xl font-bold">terminal</span>
                  </div>
                </div>
                <div className="glass-card p-8 rounded-3xl hover:border-primary/30 transition-all duration-500 border border-white/5">
                  <div className="flex flex-col md:flex-row md:items-center justify-between mb-4">
                    <h4 className="text-white text-2xl font-bold">Senior Backend Engineer</h4>
                    <span className="inline-block bg-primary/10 text-primary text-[10px] px-3 py-1.5 rounded-lg font-black uppercase tracking-widest mt-2 md:mt-0 border border-primary/20">2022 - Present</span>
                  </div>
                  <h5 className="text-primary font-bold text-base mb-6 uppercase tracking-wider">TechFlow Systems</h5>
                  <ul className="space-y-4 text-slate-300 text-sm font-light">
                    <li className="flex items-start gap-3">
                      <span className="material-symbols-outlined text-primary/50 text-lg">check_circle</span>
                      <span>Architected a serverless microservices backend handling 50k+ daily active users using <strong>Node.js</strong> and AWS Lambda.</span>
                    </li>
                    <li className="flex items-start gap-3">
                      <span className="material-symbols-outlined text-primary/50 text-lg">check_circle</span>
                      <span>Led the migration of legacy REST APIs to GraphQL, improving frontend data fetching efficiency by 60%.</span>
                    </li>
                    <li className="flex items-start gap-3">
                      <span className="material-symbols-outlined text-primary/50 text-lg">check_circle</span>
                      <span>Integrated OpenAI GPT-4 API for automated customer support agents, reducing support ticket volume by 35%.</span>
                    </li>
                  </ul>
                  <div className="mt-8 flex flex-wrap gap-2">
                    {['Node.js', 'AWS', 'DynamoDB', 'GraphQL', 'Docker'].map(tag => (
                      <span key={tag} className="px-3 py-1.5 bg-surface-dark rounded-lg text-[10px] font-bold text-slate-400 border border-slate-700 uppercase tracking-widest">
                        {tag}
                      </span>
                    ))}
                  </div>
                </div>
              </div>

              {/* Job 2 */}
              <div className="relative grid grid-cols-[60px_1fr] md:grid-cols-[80px_1fr] gap-x-8 group">
                <div className="flex flex-col items-center pt-2 z-10">
                  <div className="h-14 w-14 rounded-2xl bg-slate-800/80 border-2 border-slate-700 group-hover:border-primary transition-all duration-500 flex items-center justify-center">
                    <span className="material-symbols-outlined text-slate-400 group-hover:text-primary transition-colors text-2xl font-bold">token</span>
                  </div>
                </div>
                <div className="glass-card p-8 rounded-3xl hover:border-primary/30 transition-all duration-500 border border-white/5">
                  <div className="flex flex-col md:flex-row md:items-center justify-between mb-4">
                    <h4 className="text-white text-2xl font-bold">Full Stack Developer</h4>
                    <span className="inline-block bg-slate-800 text-slate-400 text-[10px] px-3 py-1.5 rounded-lg font-black uppercase tracking-widest mt-2 md:mt-0 border border-white/5">2020 - 2022</span>
                  </div>
                  <h5 className="text-slate-400 font-bold text-base mb-6 uppercase tracking-wider">Web3 Solutions</h5>
                  <ul className="space-y-4 text-slate-300 text-sm font-light">
                    <li className="flex items-start gap-3">
                      <span className="material-symbols-outlined text-slate-500 text-lg">check_circle</span>
                      <span>Developed smart contracts in Solidity for a DeFi lending protocol with $10M TVL.</span>
                    </li>
                    <li className="flex items-start gap-3">
                      <span className="material-symbols-outlined text-slate-500 text-lg">check_circle</span>
                      <span>Built real-time dashboarding features using React, Web3.js, and WebSockets.</span>
                    </li>
                    <li className="flex items-start gap-3">
                      <span className="material-symbols-outlined text-slate-500 text-lg">check_circle</span>
                      <span>Implemented secure wallet authentication flows (MetaMask, WalletConnect).</span>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Technical Skills Grid */}
        <div className="mb-20">
          <h3 className="text-white text-3xl font-black tracking-tight uppercase mb-12 border-b border-slate-800 pb-6">Core Technologies</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[
              { icon: 'dns', title: 'Node.js Ecosystem', subtitle: 'NestJS, Express, Fastify', color: 'text-green-400', bg: 'bg-green-500/10' },
              { icon: 'cloud', title: 'Cloud Infrastructure', subtitle: 'AWS, Google Cloud, Azure', color: 'text-blue-400', bg: 'bg-blue-500/10' },
              { icon: 'smart_toy', title: 'GenAI & LLMs', subtitle: 'LangChain, OpenAI, Vector DBs', color: 'text-primary', bg: 'bg-primary/10' },
              { icon: 'currency_bitcoin', title: 'Web3 & Blockchain', subtitle: 'Solidity, Ethers.js, Hardhat', color: 'text-purple-400', bg: 'bg-purple-500/10' },
              { icon: 'deployed_code', title: 'DevOps', subtitle: 'Docker, K8s, GitHub Actions', color: 'text-orange-400', bg: 'bg-orange-500/10' },
              { icon: 'database', title: 'Databases', subtitle: 'PostgreSQL, MongoDB, Redis', color: 'text-indigo-400', bg: 'bg-indigo-500/10' },
            ].map((skill, i) => (
              <div key={i} className="glass-card p-6 rounded-2xl flex items-center gap-5 hover:bg-white/5 transition-all duration-300 group border border-white/5">
                <div className={`size-14 rounded-xl flex items-center justify-center ${skill.bg} ${skill.color} transition-transform duration-500 group-hover:scale-110`}>
                  <span className="material-symbols-outlined text-[32px]">{skill.icon}</span>
                </div>
                <div>
                  <p className="text-white font-bold">{skill.title}</p>
                  <p className="text-slate-500 text-[10px] font-bold uppercase tracking-widest mt-1">{skill.subtitle}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Bottom CTA */}
        <div className="flex justify-center">
          <button className="group relative flex min-w-[260px] cursor-pointer items-center justify-center overflow-hidden rounded-2xl h-16 px-10 bg-gradient-to-r from-primary to-blue-600 text-background-dark gap-4 text-xl font-black shadow-2xl hover:scale-105 transition-transform duration-300">
            <span className="material-symbols-outlined font-bold">download</span>
            <span className="uppercase tracking-widest text-base">Get Full Resume</span>
          </button>
        </div>
      </div>
    </section>
  );
};
